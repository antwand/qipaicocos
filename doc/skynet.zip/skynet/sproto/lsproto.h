#ifndef __LUA_SPROTO_H_
#define __LUA_SPROTO_H_

#include "lauxlib.h"

LUALIB_API int luaopen_sproto_core(lua_State *L);

#endif